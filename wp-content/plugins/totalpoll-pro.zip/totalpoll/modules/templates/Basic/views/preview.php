<?php
! defined( 'ABSPATH' ) && exit();

include_once __DIR__ . '/preview/shared/header.php';
include_once __DIR__ . '/preview/vote.php';
include_once __DIR__ . '/preview/results.php';
include_once __DIR__ . '/preview/shared/footer.php';