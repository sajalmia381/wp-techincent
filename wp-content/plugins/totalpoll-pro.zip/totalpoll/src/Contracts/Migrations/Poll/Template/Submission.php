<?php

namespace TotalPoll\Contracts\Migrations\Poll\Template;
! defined( 'ABSPATH' ) && exit();


/**
 * Interface Submission
 * @package TotalPoll\Contracts\Migrations\Poll\Template
 */
interface Submission extends Template {

}