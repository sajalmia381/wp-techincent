<?php ! defined( 'ABSPATH' ) && exit(); ?><h3>Polls</h3>
<p>When visitors cast a vote on the poll we collect the data shown in the vote form, and also the visitor’s IP address and browser user agent string to help spam detection and assure poll functionality.</p>
<p>If you have an account and you log in to this site and cast a vote, we will also collect your user ID.</p>
<p>If you cast a vote, the vote and its metadata are retained indefinitely. This is so we can recognize and count vote for each poll.</p>