<?php
namespace WPFEPP\Constants;

if (!defined('WPINC')) die;

abstract class Admin_Pages
{
	const FORM_MANAGER = 'form_manager';
	const PLUGIN_SETTINGS = 'plugin_settings';
}