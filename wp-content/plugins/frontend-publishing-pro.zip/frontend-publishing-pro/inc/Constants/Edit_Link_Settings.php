<?php
namespace WPFEPP\Constants;

if (!defined('WPINC')) die;

abstract class Edit_Link_Settings
{
	const SETTING_POST_TYPES = 'post_types';
	const SETTING_EDIT_PAGE = 'edit_page_id';
}