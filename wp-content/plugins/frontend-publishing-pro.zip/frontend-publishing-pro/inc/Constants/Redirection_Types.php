<?php
namespace WPFEPP\Constants;

if (!defined('WPINC')) die;

class Redirection_Types
{
	const NONE = 'none';
	const CUSTOM_URL = 'custom_url';
	const POST_URL = 'post_url';
}