<?php
namespace WPFEPP\Constants;

if (!defined('WPINC')) die;

abstract class Update_Settings
{
	const SETTING_PURCHASE_CODE = 'purchase_code';
}