<?php
namespace WPFEPP\Constants;

if (!defined('WPINC')) die;

abstract class Form_Meta_Keys
{
	const FIELDS = 'fields';
	const SETTINGS = 'settings';
	const EMAILS = 'emails';
	const POST_LIST = 'post_list';
}