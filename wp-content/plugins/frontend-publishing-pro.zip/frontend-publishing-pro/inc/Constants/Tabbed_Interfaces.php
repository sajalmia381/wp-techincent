<?php
namespace WPFEPP\Constants;

if (!defined('WPINC')) die;

abstract class Tabbed_Interfaces
{
	const POST_LIST_INTERFACE = 'post_list_interface';
	const FORM_MANAGER = 'form_manager';
	const PLUGIN_SETTINGS = 'plugin_settings';
}