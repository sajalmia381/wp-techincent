<?php

if (!defined('WPINC')) die;

define('WPFEPP_PLUGIN_VERSION', '3.8.9');
define('WPFEPP_TEMPLATES_DIR', plugin_dir_path(__FILE__) . 'templates/');
define('WPFEPP_ELEMENT_TEMPLATES_DIR', WPFEPP_TEMPLATES_DIR . 'elements/');
define('WPFEPP_ELEMENT_CONTAINER_TEMPLATES_DIR', WPFEPP_TEMPLATES_DIR . 'element-containers/');
define('WPFEPP_TAB_TEMPLATES_DIR', WPFEPP_TEMPLATES_DIR . 'tabs/');