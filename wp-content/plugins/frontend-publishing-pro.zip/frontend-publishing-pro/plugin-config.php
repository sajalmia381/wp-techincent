<?php

if (!defined('WPINC')) die;

return array(
	"name"        => "Frontend Publishing Pro",
	"text_domain" => "frontend-publishing-pro",
	"prefix"      => "wpfepp",
	"version"     => WPFEPP_PLUGIN_VERSION,
	"debug"       => false
);