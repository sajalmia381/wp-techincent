<?php if (!defined('WPINC')) die; ?>
<label class="inline-edit-status alignleft">
	<span class="title"><?php echo $label; ?></span><?php echo $field_html; ?>
</label>