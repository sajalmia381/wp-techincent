<?php if (!defined('WPINC')) die; ?>
<div>
	<?php echo $label; ?>
	<div class="form-manager-error-container"><?php echo $errors; ?></div>
	<?php echo $field_html; ?>
</div>